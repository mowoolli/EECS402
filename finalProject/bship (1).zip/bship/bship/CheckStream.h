#ifndef _CHECKSTREAM_H_
#define _CHECKSTREAM_H_

// Check Stream

#include <iostream>
#include <fstream>

using namespace std;

bool checkStream(std::istream &Stream);

#endif /* defined(__proj4__CheckStream__) */

